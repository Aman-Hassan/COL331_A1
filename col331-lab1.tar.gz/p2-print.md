Self study the diff:

`git diff p1-booting`
